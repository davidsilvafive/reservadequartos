package br.com.controle;

public class Controle {
    private String nome;
    
    private int qtdias;
    private double calcularvalortotal;
    private double valortotal;
    private int clientesMais3Dias;
    private double maiorvalor;
    private double maiorvalorsetado;

    // Getters e Setters
    public String getNome(String valueOf) {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtdias(Integer valueOf) {
        return qtdias;
    }

    public void setQtdias(int qtdias) {
        this.qtdias = qtdias;
    }
  
    public double calcularvalortotal() {
        this.valortotal = this.qtdias * 100;
        return this.valortotal;
    }
    
    public double getValortotal() {
        return this.valortotal;
    }
    
    public int mais3dias() {
        if (this.qtdias > 3) {
            this.clientesMais3Dias++;
        }
        return this.clientesMais3Dias;
    }
    
public double maiorvalor() {
    // Calcula o valor da estadia atual
    double valorAtual = this.qtdias * 100.00;

    // Verifica se o valor da estadia atual é maior do que o maior valor registrado
    if (valorAtual > this.maiorvalor) {
        this.maiorvalor = valorAtual; // Atualiza o maior valor se necessário
    }

    return this.maiorvalor; // Retorna o maior valor registrado
}

}


