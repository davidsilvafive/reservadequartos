/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

public class controle {
    private double altura;
    private double peso;
    private double getAltura;
    private double getPeso;
    public String getimc;

    public double getAltura(Double valueOf) {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso(Double valueOf) {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    public double getimc(){
        return this.peso/(this.altura * this.altura);
    
    }
    
    
}
