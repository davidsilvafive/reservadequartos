/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.visao;
import br.com.controle.controle;
import javax.swing.JOptionPane;
public class visao {
    public static void main(String[] args) {
        controle c = new controle();
        
        c.setPeso(Double.valueOf(JOptionPane.showInputDialog("Digite o peso (kg)")));
        c.setAltura(Double.valueOf(JOptionPane.showInputDialog("Digite a Altura")));
        
        JOptionPane.showMessageDialog(null, "Seu imc é  " + c.getimc());
        
        
        
    }
}
