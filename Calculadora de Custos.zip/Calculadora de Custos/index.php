<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Manutenção de Carro</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
  
    <div class="container">
        <h3><center>Calculadora de Custo de Manutenção de Carro</center></h3>
        <form action="index.php" method="post">
            <label for="servico">Serviço Realizado:</label>
            <input type="text" id="servico" name="servico" required><br><br>

            <label for="valorServico">Valor do Serviço:</label>
            <input type="number" id="valorServico" name="valorServico" step="0.01" required><br><br>

            <label for="quantidadePecas">Quantidade de Peças:</label>
            <input type="number" id="quantidadePecas" name="quantidadePecas" required><br><br>

            <label for="valorPeca">Valor por Peça:</label>
            <input type="number" id="valorPeca" name="valorPeca" step="0.01" required><br><br>

            <input type="submit" value="Calcular Custo">
        </form>
        
        <div class="resultado">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                class ManutencaoCarro {
                
                    private $servico;
                    private $valorServico;
                    private $quantidadePecas;
                    private $valorPeca;

                    public function __construct($servico, $valorServico, $quantidadePecas, $valorPeca) {
                        $this->servico = $servico;
                        $this->valorServico = $valorServico;
                        $this->quantidadePecas = $quantidadePecas;
                        $this->valorPeca = $valorPeca;
                    }

                    public function calcularCustoManutencao() {
                        $custoPecas = $this->quantidadePecas * $this->valorPeca;
                        $custoTotal = $this->valorServico + $custoPecas;
                        return $custoTotal;
                    }
                }

                $servico = isset($_POST['servico']) ? $_POST['servico'] : '';
                $valorServico = isset($_POST['valorServico']) ? floatval($_POST['valorServico']) : 0.0;
                $quantidadePecas = isset($_POST['quantidadePecas']) ? intval($_POST['quantidadePecas']) : 0;
                $valorPeca = isset($_POST['valorPeca']) ? floatval($_POST['valorPeca']) : 0.0;

                $manutencao = new ManutencaoCarro($servico, $valorServico, $quantidadePecas, $valorPeca);
                $custoTotal = $manutencao->calcularCustoManutencao();

                echo "<h2>Custo Total da Manutenção: R$ " . number_format($custoTotal, 2, ',', '.') . "</h2>";
            }
            ?>
        </div>
    </div>
</body>
</html>
