<?php
class ManutencaoCarro {
 
    private $servico;
    private $valorServico;
    private $quantidadePecas;
    private $valorPeca;

    
    public function __construct($servico, $valorServico, $quantidadePecas, $valorPeca) {
        $this->servico = $servico;
        $this->valorServico = $valorServico;
        $this->quantidadePecas = $quantidadePecas;
        $this->valorPeca = $valorPeca;
    }

    
    public function calcularCustoManutencao() {
        $custoPecas = $this->quantidadePecas * $this->valorPeca;
        $custoTotal = $this->valorServico + $custoPecas;
        return $custoTotal;
    }
}
?>
